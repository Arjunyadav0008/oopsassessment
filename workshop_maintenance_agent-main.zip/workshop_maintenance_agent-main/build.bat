@echo off
rem Builds with MSVC on Windows. Finds Visual Studio if cl is not already on PATH.
setlocal
cd /d "%~dp0"

where cl >nul 2>nul
if not errorlevel 1 goto configure

set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
if not exist "%VSWHERE%" goto novs
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSPATH=%%i"
if not defined VSPATH goto novs
call "%VSPATH%\VC\Auxiliary\Build\vcvars64.bat" >nul 2>nul

:configure
cmake -S . -B build -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 exit /b 1
cmake --build build
exit /b %errorlevel%

:novs
echo Visual Studio C++ tools not found. Use CMake with your own compiler instead.
exit /b 1
