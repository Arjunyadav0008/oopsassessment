#pragma once
#include <sstream>

#include "core/MaintenanceRule.h"

class RunningHoursRule : public MaintenanceRule {
public:
    explicit RunningHoursRule(double intervalHours) : intervalHours_(intervalHours) {}

    std::string name() const override { return "Running hours"; }

    std::optional<std::string> check(const Machine& machine, int) const override {
        if (machine.hoursSinceService() < intervalHours_) return std::nullopt;
        std::ostringstream reason;
        reason << machine.hoursSinceService() << " h since service (limit " << intervalHours_ << " h)";
        return reason.str();
    }

private:
    double intervalHours_;
};
