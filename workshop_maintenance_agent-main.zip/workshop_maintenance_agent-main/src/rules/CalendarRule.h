#pragma once
#include <sstream>

#include "core/MaintenanceRule.h"

class CalendarRule : public MaintenanceRule {
public:
    explicit CalendarRule(int intervalDays) : intervalDays_(intervalDays) {}

    std::string name() const override { return "Calendar"; }

    std::optional<std::string> check(const Machine& machine, int today) const override {
        int days = today - machine.lastServiceDay;
        if (days < intervalDays_) return std::nullopt;
        std::ostringstream reason;
        reason << days << " days since service (limit " << intervalDays_ << " days)";
        return reason.str();
    }

private:
    int intervalDays_;
};
