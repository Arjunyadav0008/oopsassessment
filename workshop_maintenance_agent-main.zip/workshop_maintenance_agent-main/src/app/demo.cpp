// Scripted demo: 120 simulated days for two virtual machines.
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>

#include "app/Scenario.h"
#include "extensions/VibrationRule.h"
#include "notify/ConsoleNotifier.h"
#include "notify/FileNotifier.h"
#include "storage/CsvMachineStore.h"
#include "storage/InMemoryMachineStore.h"

namespace {
SimulationResult runScenario(MachineStore& store, Notifier& notifier, const RuleList& rules, std::ostream& out) {
    SimClock clock;
    return runWorkshopScenario(store, notifier, rules, clock, out);
}

void printComparison(const SimulationResult& before, const SimulationResult& after) {
    auto row = [](const std::string& label, auto a, auto b) {
        std::cout << std::left << std::setw(24) << label << std::setw(16) << a << b << '\n';
    };
    row("", "Base rules", "With vibration");
    row("Breakdowns", before.breakdowns, after.breakdowns);
    row("Downtime (days)", before.downtimeDays, after.downtimeDays);
    row("Lost production (h)", before.lostHours, after.lostHours);
}
}  // namespace

int main() {
    ConsoleNotifier console(std::cout);

    std::cout << "=== Run 1: running-hours and calendar rules only ===\n";
    InMemoryMachineStore firstStore;
    SimulationResult before = runScenario(firstStore, console, baseRules(), std::cout);

    std::cout << "\n=== Run 2: swap in CSV storage and log-file alerts ===\n";
    std::filesystem::create_directories("demo_output");
    std::filesystem::remove("demo_output/machines.csv");
    std::filesystem::remove("demo_output/alerts.log");
    CsvMachineStore csvStore("demo_output/machines.csv");
    FileNotifier fileNotifier("demo_output/alerts.log");
    std::ostream silent(nullptr);
    SimulationResult swapped = runScenario(csvStore, fileNotifier, baseRules(), silent);
    bool same = swapped.breakdowns == before.breakdowns && swapped.downtimeDays == before.downtimeDays &&
                swapped.alerts.size() == before.alerts.size();
    std::cout << (same ? "  Same result as Run 1. " : "  RESULT DIFFERS FROM RUN 1. ")
              << "Files written to demo_output/\n";

    std::cout << "\n=== Run 3: extension added (vibration rule) ===\n";
    RuleList extendedRules = baseRules();
    extendedRules.push_back(std::make_shared<VibrationRule>(kVibrationWarningMmS));  // the only wiring change
    InMemoryMachineStore thirdStore;
    SimulationResult after = runScenario(thirdStore, console, extendedRules, std::cout);

    std::cout << "\n=== Result over " << kScenarioDays << " days ===\n";
    printComparison(before, after);
    std::cout << "\nThe vibration rule warned on day " << after.firstAlertDay << ", "
              << before.firstBreakdownDay - after.firstAlertDay << " days before the breakdown on day "
              << before.firstBreakdownDay << ".\n";

    return same ? 0 : 1;
}
