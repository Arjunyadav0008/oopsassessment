#pragma once
#include <iosfwd>
#include <memory>
#include <string>
#include <utility>
#include <vector>

#include "core/Clock.h"
#include "core/MachineStore.h"
#include "services/MachineRegistry.h"
#include "services/MaintenanceChecker.h"
#include "services/ServiceRecorder.h"
#include "services/UsageLogger.h"

// Each role is one menu that receives only the service it is allowed to use.
class RoleMenu {
public:
    virtual ~RoleMenu() = default;
    virtual std::string title() const = 0;
    virtual void run(std::istream& in, std::ostream& out) = 0;
};

class OperatorMenu : public RoleMenu {
public:
    explicit OperatorMenu(UsageLogger& logger) : logger_(logger) {}
    std::string title() const override { return "Operator: log machine usage"; }
    void run(std::istream& in, std::ostream& out) override;

private:
    UsageLogger& logger_;
};

class TechnicianMenu : public RoleMenu {
public:
    TechnicianMenu(const MaintenanceChecker& checker, ServiceRecorder& recorder, const Clock& clock)
        : checker_(checker), recorder_(recorder), clock_(clock) {}
    std::string title() const override { return "Technician: view due work and record a service"; }
    void run(std::istream& in, std::ostream& out) override;

private:
    const MaintenanceChecker& checker_;
    ServiceRecorder& recorder_;
    const Clock& clock_;
};

class SupervisorMenu : public RoleMenu {
public:
    SupervisorMenu(const MachineReader& reader, MachineRegistry& registry)
        : reader_(reader), registry_(registry) {}
    std::string title() const override { return "Supervisor: view machines and add one"; }
    void run(std::istream& in, std::ostream& out) override;

private:
    const MachineReader& reader_;
    MachineRegistry& registry_;
};

class ConsoleApp {
public:
    ConsoleApp(std::vector<std::unique_ptr<RoleMenu>> menus, MaintenanceChecker& checker, const Clock& clock)
        : menus_(std::move(menus)), checker_(checker), clock_(clock) {}

    void run(std::istream& in, std::ostream& out);

private:
    std::vector<std::unique_ptr<RoleMenu>> menus_;
    MaintenanceChecker& checker_;
    const Clock& clock_;
};
