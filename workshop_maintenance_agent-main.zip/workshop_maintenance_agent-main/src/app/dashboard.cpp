// Runs both scenarios, writes one HTML page and opens it in the default browser.
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>

#include "app/Scenario.h"
#include "dashboard/HtmlDashboard.h"
#include "extensions/VibrationRule.h"
#include "notify/ConsoleNotifier.h"
#include "storage/InMemoryMachineStore.h"

namespace {
ScenarioRecord record(const std::string& name, const RuleList& rules, bool vibrationRuleActive) {
    InMemoryMachineStore memory;
    SimClock clock;
    HistoryStore store(memory, clock);
    std::ostringstream log;
    ConsoleNotifier notifier(log);

    ScenarioRecord scenario;
    scenario.result = runWorkshopScenario(store, notifier, rules, clock, log);
    scenario.name = name;
    scenario.vibrationRuleActive = vibrationRuleActive;
    scenario.machines = store.all();
    scenario.history = store.history();
    scenario.log = log.str();
    return scenario;
}
}  // namespace

int main(int argc, char* argv[]) {
    bool open = !(argc > 1 && std::string(argv[1]) == "--no-open");

    RuleList extendedRules = baseRules();
    extendedRules.push_back(std::make_shared<VibrationRule>(kVibrationWarningMmS));

    DashboardLimits limits{kServiceIntervalHours, kVibrationWarningMmS, SimulationSettings{}.breakdownVibrationMmS};
    std::string html = buildDashboardHtml(
        {record("Base rules", baseRules(), false), record("With vibration rule", extendedRules, true)},
        kScenarioDays, limits);

    std::filesystem::create_directories("demo_output");
    const std::filesystem::path path = "demo_output/dashboard.html";
    std::ofstream file(path, std::ios::binary);
    file << html;
    file.close();
    if (!file) {
        std::cerr << "Error: could not write " << path.string() << '\n';
        return 1;
    }
    std::cout << "Dashboard written to " << std::filesystem::absolute(path).string() << '\n';

    if (open) {
#ifdef _WIN32
        std::system("start \"\" demo_output\\dashboard.html");
#else
        std::system("xdg-open demo_output/dashboard.html");
#endif
    }
    return 0;
}
