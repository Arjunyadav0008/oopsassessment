#pragma once
#include <memory>
#include <ostream>

#include "rules/CalendarRule.h"
#include "rules/RunningHoursRule.h"
#include "services/MachineRegistry.h"
#include "simulation/SimulatedMachineFeed.h"
#include "simulation/Simulation.h"

// The shared 120-day story used by the demo and the dashboard.
constexpr int kScenarioDays = 120;
constexpr double kServiceIntervalHours = 500.0;
constexpr int kServiceIntervalDays = 90;
constexpr double kVibrationWarningMmS = 4.5;

inline RuleList baseRules() {
    return {std::make_shared<RunningHoursRule>(kServiceIntervalHours),
            std::make_shared<CalendarRule>(kServiceIntervalDays)};
}

inline SimulationResult runWorkshopScenario(MachineStore& store, Notifier& notifier, const RuleList& rules,
                                            SimClock& clock, std::ostream& out) {
    MachineRegistry registry(store, store, clock);
    registry.add("M1", "Lathe");
    registry.add("M2", "Milling machine");

    // The lathe stays healthy. The milling machine's bearing starts wearing on day 40.
    SimulatedMachineFeed feed;
    feed.addMachine("M1", {6.0, 1.8, 0, 0.0});
    feed.addMachine("M2", {5.0, 2.0, 40, 0.16});

    UsageLogger logger(store, store);
    ServiceRecorder recorder(store, store, clock);
    MaintenanceChecker checker(store, notifier, rules);
    return Simulation(feed, store, logger, recorder, checker, clock, out).run(kScenarioDays);
}
