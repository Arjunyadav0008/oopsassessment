#include "app/ConsoleApp.h"

#include <iomanip>
#include <istream>
#include <ostream>
#include <stdexcept>

namespace {
std::string ask(std::istream& in, std::ostream& out, const std::string& prompt) {
    out << prompt;
    std::string answer;
    std::getline(in, answer);

    const char* const blanks = " \t\r";
    auto first = answer.find_first_not_of(blanks);
    if (first == std::string::npos) return "";
    return answer.substr(first, answer.find_last_not_of(blanks) - first + 1);
}

double askNumber(std::istream& in, std::ostream& out, const std::string& prompt) {
    std::string answer = ask(in, out, prompt);
    try {
        std::size_t used = 0;
        double value = std::stod(answer, &used);
        if (used == answer.size()) return value;
    } catch (const std::exception&) {
    }
    throw std::invalid_argument("Not a number: " + answer);
}
}  // namespace

void OperatorMenu::run(std::istream& in, std::ostream& out) {
    std::string id = ask(in, out, "Machine id: ");
    double hours = askNumber(in, out, "Hours run: ");
    double vibration = askNumber(in, out, "Vibration (mm/s): ");
    logger_.log(id, hours, vibration);
    out << "Usage logged.\n";
}

void TechnicianMenu::run(std::istream& in, std::ostream& out) {
    auto due = checker_.dueItems(clock_.today());
    if (due.empty()) out << "No maintenance due.\n";
    for (const Alert& alert : due) {
        out << "  " << alert.machineId << " - " << alert.ruleName << ": " << alert.reason << '\n';
    }

    std::string id = ask(in, out, "Machine id to service (blank to skip): ");
    if (id.empty()) return;
    double vibration = askNumber(in, out, "Vibration after service (mm/s): ");
    recorder_.record(id, vibration);
    out << "Service recorded.\n";
}

void SupervisorMenu::run(std::istream& in, std::ostream& out) {
    out << std::left << std::setw(8) << "Id" << std::setw(20) << "Name" << std::setw(14) << "Total hours"
        << std::setw(16) << "Since service" << "Vibration\n";
    for (const Machine& m : reader_.all()) {
        out << std::left << std::setw(8) << m.id << std::setw(20) << m.name << std::setw(14) << m.runningHours
            << std::setw(16) << m.hoursSinceService() << m.vibrationMmS << " mm/s\n";
    }

    std::string id = ask(in, out, "New machine id (blank to skip): ");
    if (id.empty()) return;
    registry_.add(id, ask(in, out, "Machine name: "));
    out << "Machine added.\n";
}

void ConsoleApp::run(std::istream& in, std::ostream& out) {
    while (in) {
        out << "\nWorkshop Maintenance Scheduler\n";
        for (std::size_t i = 0; i < menus_.size(); ++i) {
            out << "  " << i + 1 << ". " << menus_[i]->title() << '\n';
        }
        out << "  0. Exit\n";

        std::string choice = ask(in, out, "Choose: ");
        if (!in || choice == "0") return;

        std::size_t index = 0;
        for (std::size_t i = 0; i < menus_.size(); ++i) {
            if (choice == std::to_string(i + 1)) index = i + 1;
        }
        if (index == 0) {
            out << "Please choose a number from the menu.\n";
            continue;
        }

        try {
            menus_[index - 1]->run(in, out);
            checker_.notifyNew(clock_.today());
        } catch (const std::logic_error& error) {
            out << "Error: " << error.what() << '\n';
        }
    }
}
