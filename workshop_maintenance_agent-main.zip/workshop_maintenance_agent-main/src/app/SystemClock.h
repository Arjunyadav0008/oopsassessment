#pragma once
#include <chrono>

#include "core/Clock.h"

class SystemClock : public Clock {
public:
    int today() const override {
        using namespace std::chrono;
        return static_cast<int>(duration_cast<hours>(system_clock::now().time_since_epoch()).count() / 24);
    }
};
