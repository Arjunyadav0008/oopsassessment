// Composition root: the only place that picks concrete classes.
#include <filesystem>
#include <iostream>
#include <memory>
#include <string>

#include "app/ConsoleApp.h"
#include "app/SystemClock.h"
#include "extensions/VibrationRule.h"
#include "notify/ConsoleNotifier.h"
#include "notify/FileNotifier.h"
#include "rules/CalendarRule.h"
#include "rules/RunningHoursRule.h"
#include "storage/CsvMachineStore.h"
#include "storage/InMemoryMachineStore.h"

namespace {
int usage() {
    std::cerr << "Usage: workshop [--store memory|csv] [--notify console|file]\n";
    return 1;
}
}  // namespace

int main(int argc, char* argv[]) {
    std::string storeKind = "csv";
    std::string notifyKind = "console";
    for (int i = 1; i + 1 < argc; i += 2) {
        std::string flag = argv[i];
        if (flag == "--store") storeKind = argv[i + 1];
        else if (flag == "--notify") notifyKind = argv[i + 1];
        else return usage();
    }
    if (argc % 2 == 0) return usage();
    if (storeKind != "memory" && storeKind != "csv") return usage();
    if (notifyKind != "console" && notifyKind != "file") return usage();

    try {
        std::filesystem::create_directories("data");

        std::unique_ptr<MachineStore> store;
        if (storeKind == "csv") store = std::make_unique<CsvMachineStore>("data/machines.csv");
        else store = std::make_unique<InMemoryMachineStore>();

        std::unique_ptr<Notifier> notifier;
        if (notifyKind == "file") notifier = std::make_unique<FileNotifier>("data/alerts.log");
        else notifier = std::make_unique<ConsoleNotifier>(std::cout);

        RuleList rules = {std::make_shared<RunningHoursRule>(500.0), std::make_shared<CalendarRule>(90)};
        rules.push_back(std::make_shared<VibrationRule>(4.5));

        SystemClock clock;
        MachineRegistry registry(*store, *store, clock);
        if (store->all().empty()) {
            registry.add("M1", "Lathe");
            registry.add("M2", "Milling machine");
        }

        UsageLogger logger(*store, *store);
        ServiceRecorder recorder(*store, *store, clock);
        MaintenanceChecker checker(*store, *notifier, rules);

        std::vector<std::unique_ptr<RoleMenu>> menus;
        menus.push_back(std::make_unique<OperatorMenu>(logger));
        menus.push_back(std::make_unique<TechnicianMenu>(checker, recorder, clock));
        menus.push_back(std::make_unique<SupervisorMenu>(*store, registry));

        ConsoleApp(std::move(menus), checker, clock).run(std::cin, std::cout);
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
