#pragma once
#include "core/Machine.h"

class Notifier {
public:
    virtual ~Notifier() = default;
    virtual void send(const Alert& alert) = 0;
};
