#pragma once
#include <optional>
#include <string>

#include "core/Machine.h"

// Contract for every rule: check() changes nothing, does not throw, and returns
// a reason only when the machine needs maintenance.
class MaintenanceRule {
public:
    virtual ~MaintenanceRule() = default;
    virtual std::string name() const = 0;
    virtual std::optional<std::string> check(const Machine& machine, int today) const = 0;
};
