#pragma once

// Time is a whole day number so that rules and tests never touch the real date.
class Clock {
public:
    virtual ~Clock() = default;
    virtual int today() const = 0;
};
