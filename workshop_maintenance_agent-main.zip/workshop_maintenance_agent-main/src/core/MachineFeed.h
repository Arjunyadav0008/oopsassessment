#pragma once
#include <string>

struct Reading {
    double hoursRun = 0;
    double vibrationMmS = 0;
};

// Where daily readings come from. The demo uses a simulation, and a real
// hour meter or vibration sensor would implement this same interface.
class MachineFeed {
public:
    virtual ~MachineFeed() = default;
    virtual Reading read(const std::string& machineId, int day) const = 0;
    virtual void onServiced(const std::string& machineId) = 0;
};
