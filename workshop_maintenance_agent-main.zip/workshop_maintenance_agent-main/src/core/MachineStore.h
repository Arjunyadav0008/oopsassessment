#pragma once
#include <optional>
#include <stdexcept>
#include <string>
#include <vector>

#include "core/Machine.h"

// Contract for every store:
//  - find() returns nothing for an unknown id and never throws for that case.
//  - save() inserts a new machine or replaces the one with the same id.
//  - all() keeps insertion order.
class MachineReader {
public:
    virtual ~MachineReader() = default;
    virtual std::optional<Machine> find(const std::string& id) const = 0;
    virtual std::vector<Machine> all() const = 0;
};

class MachineWriter {
public:
    virtual ~MachineWriter() = default;
    virtual void save(const Machine& machine) = 0;
};

class MachineStore : public MachineReader, public MachineWriter {};

inline Machine requireMachine(const MachineReader& reader, const std::string& id) {
    auto machine = reader.find(id);
    if (!machine) throw std::invalid_argument("Unknown machine: " + id);
    return *machine;
}
