#pragma once
#include <string>

struct Machine {
    std::string id;
    std::string name;
    double runningHours = 0;
    double hoursAtLastService = 0;
    int lastServiceDay = 0;
    double vibrationMmS = 0;

    double hoursSinceService() const { return runningHours - hoursAtLastService; }
};

struct Alert {
    std::string machineId;
    std::string ruleName;
    std::string reason;
    int day = 0;
};
