#pragma once
#include <sstream>

#include "core/MaintenanceRule.h"

// Extension: condition-based maintenance. Flags a machine from how it is running
// rather than how long it has run, so it can catch a fault between scheduled services.
class VibrationRule : public MaintenanceRule {
public:
    explicit VibrationRule(double limitMmS) : limitMmS_(limitMmS) {}

    std::string name() const override { return "Vibration"; }

    std::optional<std::string> check(const Machine& machine, int) const override {
        if (machine.vibrationMmS < limitMmS_) return std::nullopt;
        std::ostringstream reason;
        reason << machine.vibrationMmS << " mm/s (limit " << limitMmS_ << " mm/s)";
        return reason.str();
    }

private:
    double limitMmS_;
};
