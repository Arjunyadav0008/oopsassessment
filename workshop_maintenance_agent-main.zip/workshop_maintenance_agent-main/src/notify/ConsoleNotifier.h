#pragma once
#include <ostream>

#include "core/Notifier.h"

class ConsoleNotifier : public Notifier {
public:
    explicit ConsoleNotifier(std::ostream& out) : out_(out) {}

    void send(const Alert& alert) override {
        out_ << "  [ALERT day " << alert.day << "] " << alert.machineId << " - " << alert.ruleName
             << ": " << alert.reason << '\n';
    }

private:
    std::ostream& out_;
};
