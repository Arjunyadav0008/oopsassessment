#pragma once
#include <fstream>
#include <stdexcept>
#include <string>

#include "core/Notifier.h"

class FileNotifier : public Notifier {
public:
    explicit FileNotifier(const std::string& path) : file_(path, std::ios::app) {
        if (!file_) throw std::runtime_error("Cannot open " + path);
    }

    void send(const Alert& alert) override {
        file_ << "day " << alert.day << ',' << alert.machineId << ',' << alert.ruleName << ','
              << alert.reason << '\n';
        file_.flush();
    }

private:
    std::ofstream file_;
};
