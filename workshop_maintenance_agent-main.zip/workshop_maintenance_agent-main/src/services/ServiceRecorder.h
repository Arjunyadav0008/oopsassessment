#pragma once
#include <stdexcept>
#include <string>

#include "core/Clock.h"
#include "core/MachineStore.h"

class ServiceRecorder {
public:
    ServiceRecorder(const MachineReader& reader, MachineWriter& writer, const Clock& clock)
        : reader_(reader), writer_(writer), clock_(clock) {}

    void record(const std::string& id, double vibrationAfterService) {
        if (vibrationAfterService < 0) throw std::invalid_argument("Readings cannot be negative");
        Machine machine = requireMachine(reader_, id);
        machine.hoursAtLastService = machine.runningHours;
        machine.lastServiceDay = clock_.today();
        machine.vibrationMmS = vibrationAfterService;
        writer_.save(machine);
    }

private:
    const MachineReader& reader_;
    MachineWriter& writer_;
    const Clock& clock_;
};
