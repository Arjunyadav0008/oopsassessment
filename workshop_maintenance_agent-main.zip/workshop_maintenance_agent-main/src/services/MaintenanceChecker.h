#pragma once
#include <memory>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include "core/MachineStore.h"
#include "core/MaintenanceRule.h"
#include "core/Notifier.h"

using RuleList = std::vector<std::shared_ptr<const MaintenanceRule>>;

class MaintenanceChecker {
public:
    MaintenanceChecker(const MachineReader& reader, Notifier& notifier, RuleList rules)
        : reader_(reader), notifier_(notifier), rules_(std::move(rules)) {}

    // Everything currently due, with no side effects.
    std::vector<Alert> dueItems(int today) const;

    // Sends each alert once. An alert can fire again after its rule has cleared.
    std::vector<Alert> notifyNew(int today);

private:
    const MachineReader& reader_;
    Notifier& notifier_;
    RuleList rules_;
    std::set<std::pair<std::string, std::string>> alreadySent_;
};
