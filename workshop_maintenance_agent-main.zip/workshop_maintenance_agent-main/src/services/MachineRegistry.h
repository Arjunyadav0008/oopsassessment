#pragma once
#include <stdexcept>
#include <string>

#include "core/Clock.h"
#include "core/MachineStore.h"

class MachineRegistry {
public:
    MachineRegistry(const MachineReader& reader, MachineWriter& writer, const Clock& clock)
        : reader_(reader), writer_(writer), clock_(clock) {}

    // Names are validated here, not in the stores, so every store accepts the same input.
    void add(const std::string& id, const std::string& name) {
        if (id.empty() || name.empty()) throw std::invalid_argument("Id and name are required");
        if ((id + name).find_first_of(",\r\n") != std::string::npos)
            throw std::invalid_argument("Id and name cannot contain commas or line breaks");
        if (reader_.find(id)) throw std::invalid_argument("Machine already exists: " + id);

        Machine machine;
        machine.id = id;
        machine.name = name;
        machine.lastServiceDay = clock_.today();
        writer_.save(machine);
    }

private:
    const MachineReader& reader_;
    MachineWriter& writer_;
    const Clock& clock_;
};
