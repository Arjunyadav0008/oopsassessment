#include "services/MaintenanceChecker.h"

std::vector<Alert> MaintenanceChecker::dueItems(int today) const {
    std::vector<Alert> due;
    for (const Machine& machine : reader_.all()) {
        for (const auto& rule : rules_) {
            if (auto reason = rule->check(machine, today)) {
                due.push_back({machine.id, rule->name(), *reason, today});
            }
        }
    }
    return due;
}

std::vector<Alert> MaintenanceChecker::notifyNew(int today) {
    std::vector<Alert> fresh;
    std::set<std::pair<std::string, std::string>> stillDue;

    for (const Alert& alert : dueItems(today)) {
        std::pair<std::string, std::string> key{alert.machineId, alert.ruleName};
        stillDue.insert(key);
        if (alreadySent_.count(key) == 0) {
            notifier_.send(alert);
            fresh.push_back(alert);
        }
    }
    alreadySent_ = std::move(stillDue);
    return fresh;
}
