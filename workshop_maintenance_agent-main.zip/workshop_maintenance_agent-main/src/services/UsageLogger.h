#pragma once
#include <stdexcept>
#include <string>

#include "core/MachineStore.h"

class UsageLogger {
public:
    UsageLogger(const MachineReader& reader, MachineWriter& writer) : reader_(reader), writer_(writer) {}

    void log(const std::string& id, double hoursRun, double vibrationMmS) {
        if (hoursRun < 0 || vibrationMmS < 0) throw std::invalid_argument("Readings cannot be negative");
        Machine machine = requireMachine(reader_, id);
        machine.runningHours += hoursRun;
        machine.vibrationMmS = vibrationMmS;
        writer_.save(machine);
    }

private:
    const MachineReader& reader_;
    MachineWriter& writer_;
};
