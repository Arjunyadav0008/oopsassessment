#pragma once
#include <string>
#include <vector>

#include "dashboard/HistoryStore.h"
#include "simulation/Simulation.h"

struct DashboardLimits {
    double serviceHours = 0;
    double warningVibrationMmS = 0;
    double failureVibrationMmS = 0;
};

struct ScenarioRecord {
    std::string name;
    bool vibrationRuleActive = false;
    std::vector<Machine> machines;
    std::vector<DaySnapshot> history;
    std::string log;  // the simulation's event lines
    SimulationResult result;
};

// Status is 'R' running, 'D' down, or 'S' serviced that day.
struct DayRow {
    int day = 0;
    char status = 'R';
    double hoursSinceService = 0;
    double vibrationMmS = 0;
};

std::vector<DayRow> buildDayRows(const std::vector<DaySnapshot>& history, const std::string& machineId, int days);

// Returns one self-contained HTML page that needs no server or internet connection.
std::string buildDashboardHtml(const std::vector<ScenarioRecord>& scenarios, int days, const DashboardLimits& limits);
