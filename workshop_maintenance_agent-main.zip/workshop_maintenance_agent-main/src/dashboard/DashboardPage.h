#pragma once

// The dashboard page template. It is embedded here so that the program can
// produce a single working HTML file from any folder.
inline const char* const kDashboardHead = R"HTML(<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Workshop Maintenance Dashboard</title>
<style>
:root {
  color-scheme: light;
  --surface: #f4f4f1; --card: #fcfcfb; --border: #dcdbd5; --grid: #e8e7e2;
  --ink: #0b0b0b; --ink2: #52514e; --ink3: #76756f;
  --series-1: #2a78d6; --series-2: #eb6834;
  --good: #0c8a0c; --warning: #b57700; --critical: #d03b3b;
}
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    color-scheme: dark;
    --surface: #111110; --card: #1a1a19; --border: #33332f; --grid: #2a2a27;
    --ink: #f0efec; --ink2: #c3c2b7; --ink3: #979689;
    --series-1: #3987e5; --series-2: #d95926;
    --good: #3fb53f; --warning: #e0a22c; --critical: #e66767;
  }
}
* { box-sizing: border-box; }
body { margin: 0; background: var(--surface); color: var(--ink);
  font: 15px/1.45 "Segoe UI", system-ui, -apple-system, Roboto, sans-serif; }
main { max-width: 1120px; margin: 0 auto; padding: 24px 16px 40px; }
h1 { font-size: 24px; line-height: 1.2; margin: 0 0 4px; }
h2 { font-size: 15px; margin: 0 0 10px; }
.sub { color: var(--ink2); margin: 0 0 18px; }
.card { background: var(--card); border: 1px solid var(--border); border-radius: 10px; padding: 16px; }
.controls { display: flex; flex-wrap: wrap; gap: 12px 16px; align-items: center; margin-bottom: 14px; }
.tabs { display: flex; border: 1px solid var(--border); border-radius: 8px; overflow: hidden; }
.tabs button { border: 0; border-radius: 0; background: transparent; }
.tabs button[aria-pressed="true"] { background: var(--ink); color: var(--card); }
button, select { font: inherit; color: var(--ink); background: var(--card); border: 1px solid var(--border);
  border-radius: 8px; padding: 7px 12px; min-height: 36px; cursor: pointer; }
#play { min-width: 82px; }
.slider { display: flex; align-items: center; gap: 10px; flex: 1 1 220px; }
.slider input { flex: 1; min-width: 80px; accent-color: var(--ink); }
.day { font-weight: 600; font-variant-numeric: tabular-nums; min-width: 66px; }
.grid { display: grid; gap: 14px; margin-bottom: 14px; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); }
.machine header { display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-bottom: 10px; }
.machine strong { font-size: 16px; }
.swatch { display: inline-block; width: 10px; height: 10px; border-radius: 3px; margin-right: 7px; }
.status { font-size: 13px; font-weight: 600; white-space: nowrap; }
.status i { font-style: normal; margin-right: 4px; }
.stats { display: flex; gap: 28px; margin-bottom: 8px; }
.stats b { display: block; font-size: 24px; line-height: 1.2; font-variant-numeric: tabular-nums; }
.stats span { color: var(--ink2); font-size: 13px; }
.last { color: var(--ink2); font-size: 13px; min-height: 19px; margin: 0; }
.chart { position: relative; }
.chart svg { display: block; width: 100%; height: auto; }
svg text { fill: var(--ink3); font-size: 12px; }
svg text.lab { fill: var(--ink2); }
.tip { position: absolute; pointer-events: none; background: var(--card); border: 1px solid var(--border);
  border-radius: 8px; padding: 6px 9px; font-size: 13px; white-space: nowrap; display: none; z-index: 2;
  box-shadow: 0 2px 8px rgba(0,0,0,.14); }
.legend { display: flex; flex-wrap: wrap; gap: 14px; color: var(--ink2); font-size: 13px; margin-bottom: 6px; }
ol { list-style: none; margin: 0; padding: 0; max-height: 236px; overflow: auto; }
li { padding: 6px 0; border-top: 1px solid var(--grid); font-size: 14px; }
li:first-child { border-top: 0; }
li b { display: inline-block; min-width: 92px; font-size: 12px; letter-spacing: .03em; }
.empty { color: var(--ink3); font-size: 14px; margin: 0; }
table { border-collapse: collapse; width: 100%; font-variant-numeric: tabular-nums; }
th, td { text-align: right; padding: 6px 8px; border-top: 1px solid var(--grid); font-size: 14px; }
th:first-child, td:first-child { text-align: left; }
thead th { border-top: 0; color: var(--ink2); font-weight: 600; }
details { margin-top: 14px; }
summary { cursor: pointer; font-weight: 600; }
.daily { max-height: 320px; overflow: auto; margin-top: 10px; }
.note { color: var(--ink3); font-size: 13px; margin: 14px 0 0; }
</style>
</head>
<body>
<main>
  <h1>Workshop Maintenance Dashboard</h1>
  <p class="sub">A 120-day replay of two simulated machines. The milling machine's bearing starts wearing on day 40.</p>

  <section class="card controls" aria-label="Replay controls">
    <div class="tabs" id="tabs"></div>
    <button id="play">Pause</button>
    <label>Speed <select id="speed"><option value="250">Slow</option><option value="100" selected>Normal</option><option value="35">Fast</option></select></label>
    <div class="slider"><input id="slider" type="range" min="1" value="1" aria-label="Simulated day"><span class="day" id="dayLabel"></span></div>
  </section>

  <section class="grid" id="machines"></section>

  <section class="grid">
    <div class="card"><h2>Vibration (mm/s)</h2><div class="legend" id="legend1"></div><div class="chart" id="vib"></div></div>
    <div class="card"><h2>Hours since last service</h2><div class="legend" id="legend2"></div><div class="chart" id="hrs"></div></div>
  </section>

  <section class="grid">
    <div class="card"><h2>Event log</h2><div id="events"></div></div>
    <div class="card"><h2>Result over 120 days</h2><table id="compare"></table>
      <p class="note">Simulated sample data for demonstration, not real machine measurements.</p></div>
  </section>

  <details class="card"><summary>Daily data table</summary><div class="daily" id="daily"></div></details>
</main>
)HTML";

inline const char* const kDashboardScript = R"HTML(<script>
const $ = id => document.getElementById(id);
const STATUS = {
  R: {label: "Running", icon: "●", color: "var(--good)"},
  D: {label: "Down", icon: "▲", color: "var(--critical)"},
  S: {label: "Serviced", icon: "◆", color: "var(--warning)"}
};
const SERIES = ["var(--series-1)", "var(--series-2)"];
const EVENT_COLOR = {alert: "var(--warning)", breakdown: "var(--critical)", repair: "var(--good)", service: "var(--good)"};
const W = 640, H = 270, L = 40, R = 112, T = 14, B = 28;
const VIB = {el: "vib", col: 2, max: 8, ticks: [0, 2, 4, 6, 8], unit: " mm/s"};
const HRS = {el: "hrs", col: 1, max: 600, ticks: [0, 200, 400, 600], unit: " h"};

let scenarioIndex = 0, day = 1, playing = true, hover = {};
const scenario = () => DATA.scenarios[scenarioIndex];
const X = d => L + d / DATA.days * (W - L - R);
const Y = (v, c) => H - B - v / c.max * (H - T - B);

function drawTabs() {
  $("tabs").innerHTML = "";
  DATA.scenarios.forEach((s, i) => {
    const b = document.createElement("button");
    b.textContent = s.name;
    b.setAttribute("aria-pressed", i === scenarioIndex);
    b.onclick = () => { scenarioIndex = i; drawTabs(); draw(); drawDaily(); };
    $("tabs").appendChild(b);
  });
}

function drawMachines() {
  $("machines").innerHTML = scenario().machines.map((m, i) => {
    const [status, hours, vibration] = m.days[day - 1];
    const s = STATUS[status];
    const past = scenario().events.filter(e => e.m === m.id && e.d <= day);
    const last = past[past.length - 1];
    return `<article class="card machine"><header>
        <strong><span class="swatch" style="background:${SERIES[i]}"></span>${m.name}</strong>
        <span class="status"><i style="color:${s.color}">${s.icon}</i>${s.label}</span></header>
      <div class="stats"><div><b>${vibration.toFixed(2)}</b><span>mm/s vibration</span></div>
        <div><b>${Math.round(hours)}</b><span>hours since service</span></div></div>
      <p class="last">${last ? `Day ${last.d}: ${last.x.replace(m.id + " ", "").replace(/^- /, "")}` : "No events yet"}</p></article>`;
  }).join("");
}

function refLine(c, value, label) {
  const y = Y(value, c);
  return `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="var(--ink3)" stroke-dasharray="4 4"/>
    <text class="lab" x="${W - R + 6}" y="${y + 4}">${label}</text>`;
}

function marker(c, e, machineIndex, label) {
  const row = scenario().machines[machineIndex].days[e.d - 1];
  const x = X(e.d), y = Y(row[c.col], c);
  return `<circle cx="${x}" cy="${y}" r="5" fill="${EVENT_COLOR[e.t]}" stroke="var(--card)" stroke-width="2"/>
    <text class="lab" x="${x - 9}" y="${y + 4}" text-anchor="end">${label}</text>`;
}

function drawChart(c) {
  const hoverDay = hover[c.el];
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${c.el === "vib" ? "Vibration" : "Hours since service"} by day for each machine">`;
  c.ticks.forEach(t => {
    svg += `<line x1="${L}" x2="${W - R}" y1="${Y(t, c)}" y2="${Y(t, c)}" stroke="var(--grid)"/>
      <text x="${L - 7}" y="${Y(t, c) + 4}" text-anchor="end">${t}</text>`;
  });
  for (let d = 0; d <= DATA.days; d += 30) svg += `<text x="${X(d)}" y="${H - 8}" text-anchor="middle">${d === 0 ? "Day 0" : d}</text>`;

  if (c === VIB) {
    svg += refLine(c, DATA.limits.fail, `Failure ${DATA.limits.fail}`);
    if (scenario().vibrationRule) svg += refLine(c, DATA.limits.warn, `Warning ${DATA.limits.warn}`);
  } else {
    svg += refLine(c, DATA.limits.hours, `Limit ${DATA.limits.hours}`);
  }

  const tips = [];
  scenario().machines.forEach((m, i) => {
    const points = m.days.slice(0, day).map((row, d) => `${X(d + 1).toFixed(1)},${Y(row[c.col], c).toFixed(1)}`).join(" ");
    svg += `<polyline points="${points}" fill="none" stroke="${SERIES[i]}" stroke-width="2" stroke-linejoin="round"/>`;
    tips.push({i, y: Y(m.days[day - 1][c.col], c), name: m.name});
  });

  if (c === VIB) {
    scenario().events.filter(e => e.d <= day).forEach(e => {
      const i = scenario().machines.findIndex(m => m.id === e.m);
      if (e.t === "breakdown") svg += marker(c, e, i, "Breakdown");
      if (e.t === "alert" && e.x.includes("Vibration")) svg += marker(c, e, i, "Alert");
    });
  }

  tips.sort((a, b) => a.y - b.y);
  if (tips.length === 2 && tips[1].y - tips[0].y < 15) {
    const middle = (tips[0].y + tips[1].y) / 2;
    tips[0].labelY = middle - 8; tips[1].labelY = middle + 8;
  }
  tips.forEach(t => {
    svg += `<circle cx="${X(day)}" cy="${t.y}" r="4" fill="${SERIES[t.i]}" stroke="var(--card)" stroke-width="2"/>
      <text class="lab" x="${Math.min(X(day) + 8, W - R + 6)}" y="${(t.labelY || t.y) + 4}">${t.name}</text>`;
  });

  if (hoverDay) svg += `<line x1="${X(hoverDay)}" x2="${X(hoverDay)}" y1="${T}" y2="${H - B}" stroke="var(--ink3)"/>`;
  svg += `<rect x="${L}" y="${T}" width="${W - L - R}" height="${H - T - B}" fill="transparent"/></svg><div class="tip"></div>`;

  const host = $(c.el);
  host.innerHTML = svg;
  if (hoverDay) {
    const tip = host.querySelector(".tip");
    const rows = scenario().machines.map(m => {
      const row = m.days[hoverDay - 1];
      return `${m.name}: ${(+row[c.col]).toFixed(c === VIB ? 2 : 0)}${c.unit} (${STATUS[row[0]].label})`;
    });
    tip.innerHTML = `<b>Day ${hoverDay}</b><br>${rows.join("<br>")}`;
    tip.style.display = "block";
    const px = X(hoverDay) / W * host.clientWidth;
    tip.style.top = "6px";
    if (px > host.clientWidth / 2) { tip.style.right = (host.clientWidth - px + 10) + "px"; } else { tip.style.left = (px + 10) + "px"; }
  }
}

function drawEvents() {
  const past = scenario().events.filter(e => e.d <= day).reverse();
  $("events").innerHTML = past.length
    ? `<ol>${past.map(e => `<li><b style="color:${EVENT_COLOR[e.t]}">${e.t.toUpperCase()}</b>Day ${e.d}: ${e.x}</li>`).join("")}</ol>`
    : `<p class="empty">No events yet.</p>`;
}

function draw() {
  $("slider").value = day;
  $("dayLabel").textContent = `Day ${day}`;
  drawMachines(); drawChart(VIB); drawChart(HRS); drawEvents();
}

function drawStatic() {
  const swatches = scenario().machines.map((m, i) => `<span><span class="swatch" style="background:${SERIES[i]}"></span>${m.name}</span>`).join("");
  $("legend1").innerHTML = swatches; $("legend2").innerHTML = swatches;
  const [a, b] = DATA.scenarios;
  const row = (label, key) => `<tr><td>${label}</td><td>${a.summary[key]}</td><td>${b.summary[key]}</td></tr>`;
  $("compare").innerHTML = `<thead><tr><th></th><th>${a.name}</th><th>${b.name}</th></tr></thead><tbody>
    ${row("Breakdowns", "breakdowns")}${row("Downtime (days)", "downtime")}${row("Lost production (h)", "lost")}</tbody>`;
}

function drawDaily() {
  const names = scenario().machines;
  const head = names.map(m => `<th>${m.name} status</th><th>Hours</th><th>mm/s</th>`).join("");
  let rows = "";
  for (let d = 0; d < DATA.days; d++) {
    rows += `<tr><td>${d + 1}</td>` + names.map(m => {
      const [s, h, v] = m.days[d];
      return `<td>${STATUS[s].label}</td><td>${Math.round(h)}</td><td>${v.toFixed(2)}</td>`;
    }).join("") + "</tr>";
  }
  $("daily").innerHTML = `<table><thead><tr><th>Day</th>${head}</tr></thead><tbody>${rows}</tbody></table>`;
}

function setPlaying(value) {
  playing = value;
  $("play").textContent = playing ? "Pause" : (day >= DATA.days ? "Replay" : "Play");
}

let timer;
function tick() {
  if (playing) {
    if (day < DATA.days) { day++; draw(); }
    if (day >= DATA.days) setPlaying(false);
  }
  timer = setTimeout(tick, +$("speed").value);
}

$("play").onclick = () => {
  if (!playing && day >= DATA.days) { day = 1; draw(); }
  setPlaying(!playing);
};
$("slider").max = DATA.days;
$("slider").oninput = e => { day = +e.target.value; setPlaying(false); draw(); };
[VIB, HRS].forEach(c => {
  const host = $(c.el);
  host.onmousemove = e => {
    const box = host.getBoundingClientRect();
    const d = Math.round(((e.clientX - box.left) / box.width * W - L) / (W - L - R) * DATA.days);
    const next = d >= 1 && d <= day ? d : undefined;
    if (next !== hover[c.el]) { hover[c.el] = next; drawChart(c); }
  };
  host.onmouseleave = () => { hover[c.el] = undefined; drawChart(c); };
});

drawTabs(); drawStatic(); drawDaily(); draw(); tick();
</script>
</body>
</html>
)HTML";
