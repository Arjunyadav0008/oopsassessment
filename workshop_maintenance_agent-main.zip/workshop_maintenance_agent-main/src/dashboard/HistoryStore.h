#pragma once
#include <vector>

#include "core/Clock.h"
#include "core/MachineStore.h"

struct DaySnapshot {
    int day = 0;
    Machine machine;
};

// Decorator: behaves exactly like the store it wraps and also remembers every
// save, so the dashboard gets its history without any change to the simulation.
class HistoryStore : public MachineStore {
public:
    HistoryStore(MachineStore& inner, const Clock& clock) : inner_(inner), clock_(clock) {}

    std::optional<Machine> find(const std::string& id) const override { return inner_.find(id); }
    std::vector<Machine> all() const override { return inner_.all(); }

    void save(const Machine& machine) override {
        inner_.save(machine);
        history_.push_back({clock_.today(), machine});
    }

    const std::vector<DaySnapshot>& history() const { return history_; }

private:
    MachineStore& inner_;
    const Clock& clock_;
    std::vector<DaySnapshot> history_;
};
