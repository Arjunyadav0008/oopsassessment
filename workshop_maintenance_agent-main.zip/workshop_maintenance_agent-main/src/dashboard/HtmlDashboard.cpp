#include "dashboard/HtmlDashboard.h"

#include <cctype>
#include <sstream>

#include "dashboard/DashboardPage.h"

namespace {
std::string jsonText(const std::string& text) {
    std::string escaped = "\"";
    for (char c : text) {
        if (c == '"' || c == '\\') (escaped += '\\') += c;
        else if (c == '<') escaped += "\\u003c";
        else if (c == '\n' || c == '\r') escaped += ' ';
        else escaped += c;
    }
    return escaped + "\"";
}

// Turns "  [ALERT day 56] M2 - reason" into a JSON event.
std::string eventsJson(const std::string& log) {
    std::ostringstream json;
    json << '[';
    std::istringstream lines(log);
    std::string line;
    bool first = true;
    while (std::getline(lines, line)) {
        auto open = line.find('[');
        auto close = line.find(']');
        if (open == std::string::npos || close == std::string::npos) continue;

        std::istringstream header(line.substr(open + 1, close - open - 1));
        std::string type, dayWord;
        int day = 0;
        header >> type >> dayWord >> day;
        for (char& c : type) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));

        std::string text = line.substr(close + 2);
        json << (first ? "" : ",") << "{\"d\":" << day << ",\"t\":" << jsonText(type)
             << ",\"m\":" << jsonText(text.substr(0, text.find(' '))) << ",\"x\":" << jsonText(text) << '}';
        first = false;
    }
    json << ']';
    return json.str();
}

std::string scenarioJson(const ScenarioRecord& scenario, int days) {
    std::ostringstream json;
    json << "{\"name\":" << jsonText(scenario.name)
         << ",\"vibrationRule\":" << (scenario.vibrationRuleActive ? "true" : "false")
         << ",\"summary\":{\"breakdowns\":" << scenario.result.breakdowns
         << ",\"downtime\":" << scenario.result.downtimeDays << ",\"lost\":" << scenario.result.lostHours
         << "},\"events\":" << eventsJson(scenario.log) << ",\"machines\":[";

    for (std::size_t i = 0; i < scenario.machines.size(); ++i) {
        const Machine& machine = scenario.machines[i];
        json << (i == 0 ? "" : ",") << "{\"id\":" << jsonText(machine.id) << ",\"name\":" << jsonText(machine.name)
             << ",\"days\":[";
        bool first = true;
        for (const DayRow& row : buildDayRows(scenario.history, machine.id, days)) {
            json << (first ? "" : ",") << "[\"" << row.status << "\"," << row.hoursSinceService << ','
                 << row.vibrationMmS << ']';
            first = false;
        }
        json << "]}";
    }
    json << "]}";
    return json.str();
}
}  // namespace

std::vector<DayRow> buildDayRows(const std::vector<DaySnapshot>& history, const std::string& machineId, int days) {
    std::vector<DayRow> rows;
    Machine latest;
    for (int day = 1; day <= days; ++day) {
        bool savedToday = false;
        for (const DaySnapshot& snapshot : history) {
            if (snapshot.machine.id != machineId || snapshot.day > day) continue;
            latest = snapshot.machine;
            savedToday = snapshot.day == day;
        }

        DayRow row;
        row.day = day;
        row.hoursSinceService = latest.hoursSinceService();
        row.vibrationMmS = latest.vibrationMmS;
        if (!savedToday) row.status = 'D';
        else if (latest.lastServiceDay == day) row.status = 'S';
        rows.push_back(row);
    }
    return rows;
}

std::string buildDashboardHtml(const std::vector<ScenarioRecord>& scenarios, int days, const DashboardLimits& limits) {
    std::ostringstream data;
    data << "{\"days\":" << days << ",\"limits\":{\"hours\":" << limits.serviceHours
         << ",\"warn\":" << limits.warningVibrationMmS << ",\"fail\":" << limits.failureVibrationMmS
         << "},\"scenarios\":[";
    for (std::size_t i = 0; i < scenarios.size(); ++i) {
        data << (i == 0 ? "" : ",") << scenarioJson(scenarios[i], days);
    }
    data << "]}";

    std::string html = kDashboardHead;
    html += "<script>const DATA=" + data.str() + ";</script>\n";
    html += kDashboardScript;
    return html;
}
