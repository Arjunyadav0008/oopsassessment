#pragma once
#include <algorithm>

#include "core/MachineStore.h"

class InMemoryMachineStore : public MachineStore {
public:
    std::optional<Machine> find(const std::string& id) const override {
        auto it = std::find_if(machines_.begin(), machines_.end(),
                               [&](const Machine& m) { return m.id == id; });
        if (it == machines_.end()) return std::nullopt;
        return *it;
    }

    std::vector<Machine> all() const override { return machines_; }

    void save(const Machine& machine) override {
        auto it = std::find_if(machines_.begin(), machines_.end(),
                               [&](const Machine& m) { return m.id == machine.id; });
        if (it == machines_.end()) machines_.push_back(machine);
        else *it = machine;
    }

private:
    std::vector<Machine> machines_;
};
