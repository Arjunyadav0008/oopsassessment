#include "storage/CsvMachineStore.h"

#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <vector>

namespace {
const char* const kHeader = "id,name,runningHours,hoursAtLastService,lastServiceDay,vibrationMmS";

Machine parseRow(const std::string& row) {
    std::vector<std::string> fields;
    std::stringstream stream(row);
    std::string field;
    while (std::getline(stream, field, ',')) fields.push_back(field);
    if (fields.size() != 6) throw std::runtime_error("expected 6 fields");

    Machine machine;
    machine.id = fields[0];
    machine.name = fields[1];
    machine.runningHours = std::stod(fields[2]);
    machine.hoursAtLastService = std::stod(fields[3]);
    machine.lastServiceDay = std::stoi(fields[4]);
    machine.vibrationMmS = std::stod(fields[5]);
    return machine;
}
}  // namespace

CsvMachineStore::CsvMachineStore(std::string path) : path_(std::move(path)) { load(); }

void CsvMachineStore::save(const Machine& machine) {
    cache_.save(machine);
    writeFile();
}

void CsvMachineStore::load() {
    std::ifstream file(path_);
    if (!file) return;  // no file yet means an empty store

    std::string row;
    int lineNumber = 0;
    while (std::getline(file, row)) {
        ++lineNumber;
        if (lineNumber == 1 || row.empty()) continue;
        try {
            cache_.save(parseRow(row));
        } catch (const std::exception& error) {
            throw std::runtime_error(path_ + " line " + std::to_string(lineNumber) + ": " + error.what());
        }
    }
}

void CsvMachineStore::writeFile() const {
    std::ofstream file(path_, std::ios::trunc);
    if (!file) throw std::runtime_error("Cannot write " + path_);

    file.precision(std::numeric_limits<double>::max_digits10);
    file << kHeader << '\n';
    for (const Machine& m : cache_.all()) {
        file << m.id << ',' << m.name << ',' << m.runningHours << ',' << m.hoursAtLastService << ','
             << m.lastServiceDay << ',' << m.vibrationMmS << '\n';
    }
}
