#pragma once
#include <string>

#include "storage/InMemoryMachineStore.h"

// Keeps machines in a CSV file. Lookups come from the in-memory copy and every
// save rewrites the file, which is fine for a workshop-sized list.
class CsvMachineStore : public MachineStore {
public:
    explicit CsvMachineStore(std::string path);

    std::optional<Machine> find(const std::string& id) const override { return cache_.find(id); }
    std::vector<Machine> all() const override { return cache_.all(); }
    void save(const Machine& machine) override;

private:
    void load();
    void writeFile() const;

    std::string path_;
    InMemoryMachineStore cache_;
};
