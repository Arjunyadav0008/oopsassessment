#pragma once
#include <map>
#include <stdexcept>
#include <string>

#include "core/MachineFeed.h"

struct MachineProfile {
    double hoursPerDay = 0;
    double healthyVibrationMmS = 0;
    int wearStartDay = 0;  // 0 means this machine never develops a fault
    double wearPerDayMmS = 0;
};

// Repeatable virtual machines: the same inputs always give the same readings.
class SimulatedMachineFeed : public MachineFeed {
public:
    void addMachine(const std::string& id, const MachineProfile& profile) { profiles_[id] = profile; }

    Reading read(const std::string& machineId, int day) const override {
        const MachineProfile& profile = profileOf(machineId);
        double vibration = profile.healthyVibrationMmS;
        if (profile.wearStartDay > 0 && day > profile.wearStartDay) {
            vibration += (day - profile.wearStartDay) * profile.wearPerDayMmS;
        }
        return {profile.hoursPerDay, vibration};
    }

    // A service replaces the worn part, so the fault is gone.
    void onServiced(const std::string& machineId) override {
        profileOf(machineId);
        profiles_[machineId].wearStartDay = 0;
    }

private:
    const MachineProfile& profileOf(const std::string& id) const {
        auto it = profiles_.find(id);
        if (it == profiles_.end()) throw std::invalid_argument("No simulated machine: " + id);
        return it->second;
    }

    std::map<std::string, MachineProfile> profiles_;
};
