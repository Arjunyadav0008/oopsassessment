#pragma once
#include <iosfwd>
#include <vector>

#include "core/MachineFeed.h"
#include "core/MachineStore.h"
#include "services/MaintenanceChecker.h"
#include "services/ServiceRecorder.h"
#include "services/UsageLogger.h"
#include "simulation/SimClock.h"

struct SimulationSettings {
    double breakdownVibrationMmS = 7.1;
    int repairDays = 7;
};

struct SimulationResult {
    int breakdowns = 0;
    int firstBreakdownDay = 0;
    int firstAlertDay = 0;
    int downtimeDays = 0;
    double lostHours = 0;
    std::vector<Alert> alerts;
};

// Runs the workshop day by day. An alert books a one-day planned service for the
// next day, while a breakdown stops the machine for a longer repair.
class Simulation {
public:
    Simulation(MachineFeed& feed, const MachineReader& reader, UsageLogger& logger, ServiceRecorder& recorder,
               MaintenanceChecker& checker, SimClock& clock, std::ostream& out,
               SimulationSettings settings = {})
        : feed_(feed), reader_(reader), logger_(logger), recorder_(recorder), checker_(checker),
          clock_(clock), out_(out), settings_(settings) {}

    SimulationResult run(int days);

private:
    MachineFeed& feed_;
    const MachineReader& reader_;
    UsageLogger& logger_;
    ServiceRecorder& recorder_;
    MaintenanceChecker& checker_;
    SimClock& clock_;
    std::ostream& out_;
    SimulationSettings settings_;
};
