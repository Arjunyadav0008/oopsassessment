#pragma once
#include "core/Clock.h"

class SimClock : public Clock {
public:
    int today() const override { return day_; }
    void setDay(int day) { day_ = day; }

private:
    int day_ = 0;
};
