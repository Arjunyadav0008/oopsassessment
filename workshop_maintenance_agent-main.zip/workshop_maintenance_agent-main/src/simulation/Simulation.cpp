#include "simulation/Simulation.h"

#include <map>
#include <ostream>
#include <set>
#include <string>

SimulationResult Simulation::run(int days) {
    SimulationResult result;
    std::set<std::string> plannedService;
    std::map<std::string, int> brokenUntil;

    auto finishService = [&](const std::string& id, int day) {
        feed_.onServiced(id);
        recorder_.record(id, feed_.read(id, day).vibrationMmS);
    };

    for (int day = 1; day <= days; ++day) {
        clock_.setDay(day);

        for (const Machine& machine : reader_.all()) {
            const std::string& id = machine.id;
            Reading reading = feed_.read(id, day);

            if (brokenUntil.count(id) != 0) {
                ++result.downtimeDays;
                result.lostHours += reading.hoursRun;
                if (day == brokenUntil[id]) {
                    finishService(id, day);
                    brokenUntil.erase(id);
                    out_ << "  [REPAIR day " << day << "] " << id << " back in service\n";
                }
                continue;
            }

            if (plannedService.erase(id) != 0) {
                ++result.downtimeDays;
                result.lostHours += reading.hoursRun;
                finishService(id, day);
                out_ << "  [SERVICE day " << day << "] " << id << " planned service done\n";
                continue;
            }

            logger_.log(id, reading.hoursRun, reading.vibrationMmS);
            if (reading.vibrationMmS >= settings_.breakdownVibrationMmS) {
                ++result.breakdowns;
                if (result.firstBreakdownDay == 0) result.firstBreakdownDay = day;
                brokenUntil[id] = day + settings_.repairDays;
                out_ << "  [BREAKDOWN day " << day << "] " << id << " failed at " << reading.vibrationMmS
                     << " mm/s\n";
            }
        }

        for (const Alert& alert : checker_.notifyNew(day)) {
            result.alerts.push_back(alert);
            if (result.firstAlertDay == 0) result.firstAlertDay = day;
            if (brokenUntil.count(alert.machineId) == 0) plannedService.insert(alert.machineId);
        }
    }
    return result;
}
