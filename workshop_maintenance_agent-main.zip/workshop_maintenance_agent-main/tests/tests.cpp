// Small self-contained test runner, so the project needs no external libraries.
#include <cstdio>
#include <filesystem>
#include <functional>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

#include "dashboard/HtmlDashboard.h"
#include "extensions/VibrationRule.h"
#include "notify/ConsoleNotifier.h"
#include "notify/FileNotifier.h"
#include "rules/CalendarRule.h"
#include "rules/RunningHoursRule.h"
#include "services/MachineRegistry.h"
#include "simulation/SimulatedMachineFeed.h"
#include "simulation/Simulation.h"
#include "storage/CsvMachineStore.h"
#include "storage/InMemoryMachineStore.h"

namespace {
int failures = 0;

#define CHECK(condition)                                                                   \
    do {                                                                                   \
        if (!(condition)) {                                                                \
            ++failures;                                                                    \
            std::cout << "    FAILED line " << __LINE__ << ": " << #condition << '\n';     \
        }                                                                                  \
    } while (false)

template <typename Action>
bool throwsInvalidArgument(Action action) {
    try {
        action();
    } catch (const std::invalid_argument&) {
        return true;
    }
    return false;
}

class RecordingNotifier : public Notifier {
public:
    void send(const Alert& alert) override { sent.push_back(alert); }
    std::vector<Alert> sent;
};

Machine machineWith(double hoursSinceService, int lastServiceDay = 0, double vibration = 0) {
    Machine machine;
    machine.id = "M1";
    machine.name = "Lathe";
    machine.runningHours = 1000 + hoursSinceService;
    machine.hoursAtLastService = 1000;
    machine.lastServiceDay = lastServiceDay;
    machine.vibrationMmS = vibration;
    return machine;
}

void runningHoursRuleFiresAtTheLimit() {
    RunningHoursRule rule(500);
    CHECK(!rule.check(machineWith(499.9), 0));
    CHECK(rule.check(machineWith(500), 0));
}

void calendarRuleFiresAtTheLimit() {
    CalendarRule rule(90);
    CHECK(!rule.check(machineWith(0, 10), 99));
    CHECK(rule.check(machineWith(0, 10), 100));
}

void vibrationRuleFiresAtTheLimit() {
    VibrationRule rule(4.5);
    CHECK(!rule.check(machineWith(0, 0, 4.49), 0));
    CHECK(rule.check(machineWith(0, 0, 4.5), 0));
}

// LSP: every rule must leave the machine alone and stay quiet for a healthy one.
void everyRuleKeepsTheRuleContract() {
    RuleList rules = {std::make_shared<RunningHoursRule>(500.0), std::make_shared<CalendarRule>(90),
                      std::make_shared<VibrationRule>(4.5)};
    const Machine healthy = machineWith(1, 0, 1.0);
    for (const auto& rule : rules) {
        Machine copy = healthy;
        CHECK(!rule->check(copy, 1));
        CHECK(copy.runningHours == healthy.runningHours);
        CHECK(!rule->name().empty());
    }
}

// LSP: the same checks run against every MachineStore.
void checkStoreContract(MachineStore& store) {
    CHECK(!store.find("NONE"));
    CHECK(store.all().empty());

    Machine first = machineWith(5);
    Machine second = machineWith(6);
    second.id = "M2";
    store.save(first);
    store.save(second);
    CHECK(store.all().size() == 2);
    CHECK(store.all()[0].id == "M1");

    first.runningHours = 2000;
    store.save(first);
    CHECK(store.all().size() == 2);
    CHECK(store.find("M1")->runningHours == 2000);
}

void inMemoryStoreKeepsTheContract() {
    InMemoryMachineStore store;
    checkStoreContract(store);
}

void csvStoreKeepsTheContract() {
    const std::string path = "test_contract.csv";
    std::remove(path.c_str());
    {
        CsvMachineStore store(path);
        checkStoreContract(store);
    }
    std::remove(path.c_str());
}

void csvStoreSurvivesARestart() {
    const std::string path = "test_reload.csv";
    std::remove(path.c_str());
    Machine saved = machineWith(12.345, 7, 3.21);
    {
        CsvMachineStore store(path);
        store.save(saved);
    }
    CsvMachineStore reopened(path);
    auto loaded = reopened.find("M1");
    CHECK(loaded.has_value());
    CHECK(loaded->name == "Lathe");
    CHECK(loaded->runningHours == saved.runningHours);
    CHECK(loaded->lastServiceDay == 7);
    CHECK(loaded->vibrationMmS == saved.vibrationMmS);
    std::remove(path.c_str());
}

void csvStoreReportsABadRow() {
    const std::string path = "test_bad.csv";
    {
        std::ofstream file(path);
        file << "header\nM1,Lathe,not-a-number,0,0,0\n";
    }
    bool reported = false;
    try {
        CsvMachineStore store(path);
    } catch (const std::runtime_error& error) {
        reported = std::string(error.what()).find("line 2") != std::string::npos;
    }
    CHECK(reported);
    std::remove(path.c_str());
}

void notifiersAreInterchangeable() {
    const std::string path = "test_alerts.log";
    std::remove(path.c_str());
    const Alert alert{"M1", "Calendar", "91 days", 91};

    std::ostringstream screen;
    ConsoleNotifier console(screen);
    {
        FileNotifier file(path);
        RecordingNotifier recording;
        std::vector<Notifier*> notifiers = {&console, &file, &recording};
        for (Notifier* notifier : notifiers) notifier->send(alert);
        CHECK(recording.sent.size() == 1);
    }
    CHECK(screen.str().find("M1") != std::string::npos);

    std::ifstream written(path);
    std::string line;
    std::getline(written, line);
    CHECK(line.find("Calendar") != std::string::npos);
    written.close();
    std::remove(path.c_str());
}

void usageLoggerAddsHoursAndRejectsBadInput() {
    InMemoryMachineStore store;
    store.save(machineWith(0));
    UsageLogger logger(store, store);
    logger.log("M1", 8, 2.5);
    logger.log("M1", 2, 2.6);
    CHECK(store.find("M1")->hoursSinceService() == 10);
    CHECK(store.find("M1")->vibrationMmS == 2.6);
    CHECK(throwsInvalidArgument([&] { logger.log("NONE", 1, 1); }));
    CHECK(throwsInvalidArgument([&] { logger.log("M1", -1, 1); }));
}

void serviceResetsTheCounters() {
    InMemoryMachineStore store;
    store.save(machineWith(600, 3, 5.0));
    SimClock clock;
    clock.setDay(50);
    ServiceRecorder recorder(store, store, clock);
    recorder.record("M1", 1.5);

    Machine machine = *store.find("M1");
    CHECK(machine.hoursSinceService() == 0);
    CHECK(machine.lastServiceDay == 50);
    CHECK(machine.vibrationMmS == 1.5);
    CHECK(machine.runningHours == 1600);
}

void registryRejectsDuplicatesAndBadNames() {
    InMemoryMachineStore store;
    SimClock clock;
    clock.setDay(4);
    MachineRegistry registry(store, store, clock);
    registry.add("M1", "Lathe");
    CHECK(store.find("M1")->lastServiceDay == 4);
    CHECK(throwsInvalidArgument([&] { registry.add("M1", "Copy"); }));
    CHECK(throwsInvalidArgument([&] { registry.add("M2", "Bad,name"); }));
    CHECK(throwsInvalidArgument([&] { registry.add("", "No id"); }));
}

void checkerSendsEachAlertOnceAndAgainAfterService() {
    InMemoryMachineStore store;
    store.save(machineWith(500));
    RecordingNotifier notifier;
    MaintenanceChecker checker(store, notifier, {std::make_shared<RunningHoursRule>(500.0)});
    SimClock clock;
    ServiceRecorder recorder(store, store, clock);
    UsageLogger logger(store, store);

    checker.notifyNew(1);
    checker.notifyNew(2);
    CHECK(notifier.sent.size() == 1);
    CHECK(checker.dueItems(2).size() == 1);

    recorder.record("M1", 1.0);
    checker.notifyNew(3);
    CHECK(checker.dueItems(3).empty());

    logger.log("M1", 500, 1.0);
    checker.notifyNew(4);
    CHECK(notifier.sent.size() == 2);
}

SimulationResult runSimulation(const RuleList& rules, RecordingNotifier& notifier, InMemoryMachineStore& store) {
    SimClock clock;
    MachineRegistry registry(store, store, clock);
    registry.add("M1", "Lathe");
    registry.add("M2", "Milling machine");

    SimulatedMachineFeed feed;
    feed.addMachine("M1", {6.0, 1.8, 0, 0.0});
    feed.addMachine("M2", {5.0, 2.0, 40, 0.16});

    UsageLogger logger(store, store);
    ServiceRecorder recorder(store, store, clock);
    MaintenanceChecker checker(store, notifier, rules);
    std::ostringstream log;
    return Simulation(feed, store, logger, recorder, checker, clock, log).run(120);
}

// Hand calculation: 2.0 + 0.16 * (day - 40) first reaches 7.1 mm/s on day 72.
// The lathe reaches 500 h on day 84 (6 h/day), so it is alerted first on day 84.
void simulationMatchesHandCalculation() {
    InMemoryMachineStore store;
    RecordingNotifier notifier;
    SimulationResult result = runSimulation(
        {std::make_shared<RunningHoursRule>(500.0), std::make_shared<CalendarRule>(90)}, notifier, store);

    CHECK(result.breakdowns == 1);
    CHECK(result.firstBreakdownDay == 72);
    CHECK(result.firstAlertDay == 84);
    CHECK(result.downtimeDays == 8);    // 7 repair days on M2, 1 service day on M1
    CHECK(result.lostHours == 41);      // 7 * 5 h + 1 * 6 h
}

// Hand calculation: 2.0 + 0.16 * (day - 40) first reaches 4.5 mm/s on day 56,
// so the bearing is replaced on day 57 and the machine never reaches 7.1 mm/s.
void vibrationRulePreventsTheBreakdown() {
    InMemoryMachineStore store;
    RecordingNotifier notifier;
    SimulationResult result = runSimulation({std::make_shared<RunningHoursRule>(500.0),
                                             std::make_shared<CalendarRule>(90),
                                             std::make_shared<VibrationRule>(4.5)},
                                            notifier, store);

    CHECK(result.breakdowns == 0);
    CHECK(result.firstAlertDay == 56);
    CHECK(notifier.sent.front().ruleName == "Vibration");
    CHECK(store.find("M2")->lastServiceDay == 57);
    CHECK(result.downtimeDays == 2);    // 1 service day on each machine
    CHECK(result.lostHours == 11);      // 5 h + 6 h
}

// LSP: the recording decorator must pass the same contract as the stores it wraps.
void historyStoreKeepsTheContract() {
    InMemoryMachineStore inner;
    SimClock clock;
    HistoryStore store(inner, clock);
    checkStoreContract(store);
    CHECK(store.history().size() == 3);
    CHECK(inner.all().size() == 2);
}

void dashboardRowsShowDowntimeAndService() {
    InMemoryMachineStore inner;
    SimClock clock;
    HistoryStore store(inner, clock);
    RecordingNotifier notifier;
    SimulationSettings settings;
    std::ostringstream log;

    MachineRegistry registry(store, store, clock);
    registry.add("M2", "Milling machine");
    SimulatedMachineFeed feed;
    feed.addMachine("M2", {5.0, 2.0, 40, 0.16});
    UsageLogger logger(store, store);
    ServiceRecorder recorder(store, store, clock);
    MaintenanceChecker checker(store, notifier, RuleList{});
    Simulation(feed, store, logger, recorder, checker, clock, log, settings).run(80);

    auto rows = buildDayRows(store.history(), "M2", 80);
    CHECK(rows.size() == 80);
    CHECK(rows[71].status == 'R');  // day 72: fails at the end of the day
    CHECK(rows[72].status == 'D');  // day 73
    CHECK(rows[77].status == 'D');  // day 78
    CHECK(rows[78].status == 'S');  // day 79: repair finished
    CHECK(rows[78].hoursSinceService == 0);
}

void dashboardPageContainsItsData() {
    ScenarioRecord scenario;
    scenario.name = "Base <rules>";
    scenario.log = "  [ALERT day 56] M2 - Vibration: 4.56 mm/s\n";
    std::string html = buildDashboardHtml({scenario}, 10, {500, 4.5, 7.1});
    CHECK(html.find("\"d\":56") != std::string::npos);
    CHECK(html.find("\"t\":\"alert\"") != std::string::npos);
    CHECK(html.find("Base <rules>") == std::string::npos);  // escaped for the script block
}

struct TestCase {
    const char* name;
    std::function<void()> run;
};
}  // namespace

int main() {
    const std::vector<TestCase> tests = {
        {"running-hours rule fires at the limit", runningHoursRuleFiresAtTheLimit},
        {"calendar rule fires at the limit", calendarRuleFiresAtTheLimit},
        {"vibration rule fires at the limit", vibrationRuleFiresAtTheLimit},
        {"every rule keeps the rule contract", everyRuleKeepsTheRuleContract},
        {"in-memory store keeps the store contract", inMemoryStoreKeepsTheContract},
        {"CSV store keeps the store contract", csvStoreKeepsTheContract},
        {"CSV store survives a restart", csvStoreSurvivesARestart},
        {"CSV store reports a bad row", csvStoreReportsABadRow},
        {"notifiers are interchangeable", notifiersAreInterchangeable},
        {"usage logger adds hours and rejects bad input", usageLoggerAddsHoursAndRejectsBadInput},
        {"service resets the counters", serviceResetsTheCounters},
        {"registry rejects duplicates and bad names", registryRejectsDuplicatesAndBadNames},
        {"checker sends each alert once and again after service", checkerSendsEachAlertOnceAndAgainAfterService},
        {"simulation matches the hand calculation", simulationMatchesHandCalculation},
        {"vibration rule prevents the breakdown", vibrationRulePreventsTheBreakdown},
        {"history store keeps the store contract", historyStoreKeepsTheContract},
        {"dashboard rows show downtime and service", dashboardRowsShowDowntimeAndService},
        {"dashboard page contains its data", dashboardPageContainsItsData},
    };

    for (const TestCase& test : tests) {
        int before = failures;
        try {
            test.run();
        } catch (const std::exception& error) {
            ++failures;
            std::cout << "    EXCEPTION: " << error.what() << '\n';
        }
        std::cout << (failures == before ? "[PASS] " : "[FAIL] ") << test.name << '\n';
    }

    std::cout << '\n' << tests.size() << " tests, " << failures << " failed checks\n";
    return failures == 0 ? 0 : 1;
}
