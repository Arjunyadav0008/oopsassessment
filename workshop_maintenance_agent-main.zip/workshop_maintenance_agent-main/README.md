# Workshop Maintenance Scheduler

BCSE102L case study: a small C++17 console application that applies all five SOLID principles.

## Problem

A campus workshop needs to know when its machines are due for maintenance. The first version uses
running hours and calendar intervals. Requirements then grow: the workshop also wants to catch faults
between scheduled services. The design should absorb that change without rewriting existing code.

## Features

- Two machines by default: a lathe (M1) and a milling machine (M2). Supervisors can add more.
- Three roles: **Operator** logs usage, **Technician** views due work and records services,
  **Supervisor** views machines and adds new ones.
- Interchangeable maintenance rules: running hours, calendar, and vibration (the extension).
- Interchangeable storage: in-memory or CSV file.
- Interchangeable alerts: console or log file.
- A simulation that runs 120 days of virtual machines, so no real hardware is needed.
- A browser dashboard that replays the simulation with live status, charts and an event log.

## Build

You need a C++17 compiler and CMake. No external libraries are used.

**Windows with Visual Studio or Build Tools (tested):**

```powershell
.\build.bat
```

**Any other compiler (for example g++):**

```bash
cmake -S . -B build
cmake --build build
```

Examples below use Windows paths. With g++, drop the `.exe` and use forward slashes.

## Run

```powershell
.\build\tests.exe
.\build\demo.exe
.\build\dashboard.exe
.\build\workshop.exe
```

| Program | Purpose |
|---|---|
| `tests.exe` | 18 automated tests |
| `demo.exe` | Scripted 120-day simulation, with the before and after comparison |
| `dashboard.exe` | Writes `demo_output/dashboard.html` and opens it in your browser (`--no-open` skips opening it) |
| `workshop.exe` | Interactive menu for the three roles |

Close any running `workshop.exe` before rebuilding, because Windows locks a running program.

The dashboard needs no server or internet connection. It replays the simulated scenarios, with
a button to switch between the base rules and the vibration rule. It does not show live data from
`workshop.exe`.

`workshop.exe` options swap implementations without any code change:

```powershell
.\build\workshop.exe --store memory --notify file
```

| Option | Values | Default |
|---|---|---|
| `--store` | `memory`, `csv` (`data/machines.csv`) | `csv` |
| `--notify` | `console`, `file` (`data/alerts.log`) | `console` |

In the live app, the day shown in alerts is the number of days since 1 January 1970.

## Sample usage

Output of `demo.exe`, shortened:

```text
=== Run 1: running-hours and calendar rules only ===
  [BREAKDOWN day 72] M2 failed at 7.12 mm/s
  [ALERT day 84] M1 - Running hours: 504 h since service (limit 500 h)

=== Run 3: extension added (vibration rule) ===
  [ALERT day 56] M2 - Vibration: 4.56 mm/s (limit 4.5 mm/s)
  [SERVICE day 57] M2 planned service done

=== Result over 120 days ===
                        Base rules      With vibration
Breakdowns              1               0
Downtime (days)         8               2
Lost production (h)     41              11
```

To try the roles, run `workshop.exe`, choose Operator, and log `M2`, `40` hours, `5.2` mm/s. A vibration
alert appears. Then choose Technician and record the service for `M2`, and the alert clears.

## Testing without real machines

`SimulatedMachineFeed` produces repeatable daily readings and `SimClock` replaces the real date. The
lathe runs 6 h/day and stays healthy. The milling machine runs 5 h/day and its bearing starts wearing on
day 40, adding 0.16 mm/s per day.

The expected results are worked out by hand and asserted in `tests/tests.cpp`:

- Vibration is `2.0 + 0.16 x (day - 40)`, which first reaches the 7.1 mm/s failure level on day 72.
- The same formula first reaches the 4.5 mm/s warning level on day 56.
- The lathe reaches 500 h on day 84 at 6 h/day.

The simulation data and limits are illustrative sample values, not measurements. The 4.5 and 7.1 mm/s
limits are modelled on typical vibration severity zones.

## Design

```mermaid
classDiagram
    class MaintenanceRule { <<interface>> +check(machine, today) }
    class Notifier { <<interface>> +send(alert) }
    class MachineReader { <<interface>> +find(id) +all() }
    class MachineWriter { <<interface>> +save(machine) }
    class MachineStore { <<interface>> }
    class Clock { <<interface>> +today() }
    class MachineFeed { <<interface>> +read(id, day) +onServiced(id) }

    MaintenanceRule <|.. RunningHoursRule
    MaintenanceRule <|.. CalendarRule
    MaintenanceRule <|.. VibrationRule
    Notifier <|.. ConsoleNotifier
    Notifier <|.. FileNotifier
    MachineReader <|-- MachineStore
    MachineWriter <|-- MachineStore
    MachineStore <|.. InMemoryMachineStore
    MachineStore <|.. CsvMachineStore
    Clock <|.. SystemClock
    Clock <|.. SimClock
    MachineFeed <|.. SimulatedMachineFeed

    MaintenanceChecker --> MachineReader
    MaintenanceChecker --> Notifier
    MaintenanceChecker --> MaintenanceRule
    UsageLogger --> MachineReader
    UsageLogger --> MachineWriter
    ServiceRecorder --> MachineReader
    ServiceRecorder --> MachineWriter
    ServiceRecorder --> Clock
    Simulation --> MachineFeed
```

| Folder | Contents |
|---|---|
| `src/core` | Data types and interfaces |
| `src/rules` | Running-hours and calendar rules |
| `src/storage` | In-memory and CSV stores |
| `src/notify` | Console and file notifiers |
| `src/services` | Logging usage, recording services, registering machines, checking rules |
| `src/simulation` | Virtual clock, virtual machines, day-by-day runner |
| `src/extensions` | Vibration rule |
| `src/dashboard` | Recording store decorator and HTML page generator |
| `src/app` | Console menus, shared scenario, and the `main`, `demo` and `dashboard` programs |
| `tests` | Test suite |

| Principle | Where it is applied |
|---|---|
| Single Responsibility | Each service has one job, for example `UsageLogger`, `ServiceRecorder` and `MaintenanceChecker`. Menus only handle input and output. |
| Open/Closed | `MaintenanceChecker` loops over `MaintenanceRule` objects, so new rules need no change to it. New roles are new `RoleMenu` classes. |
| Liskov Substitution | The same contract tests run against both stores and all three rules. Run 2 of the demo swaps store and notifier and gets the same result. |
| Interface Segregation | `MachineReader` and `MachineWriter` are separate, so `MaintenanceChecker` cannot change data. Each role menu receives only the services it needs. |
| Dependency Inversion | Services depend on the interfaces in `src/core`. Concrete classes are chosen only in `main.cpp`, `demo.cpp` and the tests. |

## Demonstrated extension

**New requirement:** detect faults between scheduled services.

**What changed:**

- Added `src/extensions/VibrationRule.h`.
- Added one line to register the rule in `src/app/main.cpp`, and one in `src/app/demo.cpp`.
- Added tests for the new rule, and the demo's comparison output.

**What did not change:** every file in `src/core`, `src/rules`, `src/services`, `src/storage`,
`src/notify` and `src/simulation`.

The dashboard was added the same way. `HistoryStore` wraps any `MachineStore` and records each save, so
the simulation produces the dashboard's history without being edited, and it passes the same store
contract tests.

## Known limitations

- `Machine` already had a vibration field before the extension was added. A brand-new kind of sensor
  would need a change to `Machine`, or a more general list of readings.
- Roles are chosen from a menu and there is no login.
- The dashboard replays the simulation only. It is not connected to the interactive app.
- The CSV store rewrites the whole file on each save, so it suits a small workshop and not a large plant.
- Only the Windows MSVC build has been tested.

## Contributors

| Name | Registration number | Contribution |
|---|---|---|
| _Your name_ | _Your registration number_ | _Your contribution_ |

## AI use disclosure

Built with Claude Code using the Claude Opus 5.5 model (`claude-opus-5-5`). Claude generated the source
code, tests and README from the project idea and requirements given by the author, and ran the build and
tests. The author chose the project and reviewed the result.
